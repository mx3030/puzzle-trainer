declare let cs: {
    values: {
        "buttons:flipper": string;
        "buttons:first": string;
        "buttons:prev": string;
        "buttons:next": string;
        "buttons:play": string;
        "buttons:last": string;
        "buttons:deleteVar": string;
        "buttons:promoteVar": string;
        "buttons:deleteMoves": string;
        "buttons:nags": string;
        "buttons:pgn": string;
        "buttons:hidePGN": string;
        "chess:q": string;
        "chess:k": string;
        "chess:r": string;
        "chess:b": string;
        "chess:n": string;
        "chess:Q": string;
        "chess:K": string;
        "chess:R": string;
        "chess:B": string;
        "chess:N": string;
    };
};
export default cs;
//# sourceMappingURL=cs.d.ts.map