import { Base } from "./types";
/**
 * Original source taken from: https://github.com/ornicar/lila/blob/master/ui/common/src/resize.ts
 * @param els ??
 */
export default function resizeHandle(that: Base, outer: HTMLElement, els: HTMLElement, _width: number, resizeFunction: Function): void;
//# sourceMappingURL=resize.d.ts.map